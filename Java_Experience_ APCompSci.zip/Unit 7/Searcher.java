import java.util.*;
public class Searcher{
   public static int search(String[] arr, String str){
      for(int i = 0; i < arr.length; i++){
         if (arr[i].equals(str)){
            return i;
         }
      }
      return -1;
   }
   public static int search(List<String> myList, int num){
      for(int i = 0; i < myList.size(); i++){
         if (myList.get(i).length() == num){
            return i;
         }
      }
      return -1;
   }
   public static int binSearch(int[] array, int key){
      int left = 0;
      int right = array.length-1;
      while (left<=right){
         int mid = (right+left)/2;
         if(key == array[mid]){
            return mid;
         }
         else if(key > array[mid]){
            left = mid + 1;
         }
         else{
            right = mid - 1;
         }
      }
      return -1;
   }
}