import java.util.ArrayList;
public class SortTester{
   public static void insertionSort(ArrayList<Integer> a){
      for(int i = 1; i < a.size(); i++){
         int temp = a.get(i);
         int temp1 = i-1;
         while (temp1 >= 0 && a.get(temp1) < temp){
            a.set(temp1+1, a.get(temp1));
            temp1--;
         }
         a.set(temp1+1, temp1);
      }
   }
   public static void main(String[] args){
      ArrayList<Integer> list = new ArrayList<Integer>();
       for (int i = 0; i < 20; i++){
         int random = (int)(Math.random()*36)+15;
         list.add(random);
         System.out.println(list);
         insertionSort(list);
         System.out.println(list);
      }
   }
}