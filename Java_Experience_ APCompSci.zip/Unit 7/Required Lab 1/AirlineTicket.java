import java.util.ArrayList;
public class AirlineTicket{
   private int name, seatNum, boardingGroup;
   private String row;
   public AirlineTicket(int n){
      name = n;
      seatNum = (int)(Math.random()*8)+1;
      boardingGroup = (int)(Math.random()*5)+1;
      int tempRand = (int)(Math.random()*6);
      if (tempRand == 0){
         row = "A";
      }
      else if (tempRand == 1){
         row = "B";
      }
      else if (tempRand == 2){
         row = "C";
      }
      else if (tempRand == 3){
         row = "D";
      }
      else if (tempRand == 4){
         row = "E";
      }
      else if (tempRand == 5){
         row = "F";
      }
   }
   public String getRow(){
      return row;
   }
   public int getGroup(){
      return boardingGroup;
   }
   public String toString(){
      return "Passenger #"+name+": Row "+row+", Seat "+seatNum+", Boarding group "+boardingGroup;
   }
   public static void main(String[] args){
      ArrayList<AirlineTicket> tickets = new ArrayList<AirlineTicket>();
      for (int i = 1; i <= 15; i++){
         AirlineTicket a = new AirlineTicket(i);
         tickets.add(a);
      } 
      for (int i = 1; i <= 5; i++){
         System.out.println("Boarding group "+i+":");
         for (AirlineTicket t : tickets){
            if (t.getGroup() == i){
               System.out.println(t.toString());
            }
         }
      }
      System.out.println("Passengers boarding together:");
      for (int i = 0; i < tickets.size(); i++){
         AirlineTicket tempTicket1 = tickets.get(i);
         for (int j = i + 1; j < tickets.size(); j++){
            AirlineTicket tempTicket2 = tickets.get(j);
            if ((tempTicket1.getRow().equals(tempTicket2.getRow()) && (tempTicket1.getGroup() == tempTicket2.getGroup()))){
               System.out.println(tempTicket1.toString()+" and "+tempTicket2.toString());
            }
         }
      }
   }
}