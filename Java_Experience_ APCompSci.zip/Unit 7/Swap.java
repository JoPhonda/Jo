import java.util.*;
public class Swap{
   public void swap(List<String> words, int x, int y){
      String temp = words.remove(x);
      words.add(y, temp);
   }
   public void selectionSort(List <Comparable> elements){
      for(int i = 0; i < elements.size()-1; i++){
         int min = i;
         for(int j = i + 1; j < elements.size(); j++){
            if(elements.get(j).compareTo(elements.get(min)) < 0){
               min = j;
            }
         }
         elements.set(i, elements.set(min, elements.get(i)));
      }
   }
   public static void setNegativesToZero(List<Integer> nums){
      System.out.println(nums);
      for (int i = 0; i < nums.size(); i++){
         if(nums.get(i)<0){
            nums.set(i, 0);
         }
      }
      System.out.println(nums);
   }
   public static void removeNegatives(List<Integer> nums){
      System.out.println(nums);
      int i = 0;
      while(i < nums.size())
         if(nums.get(i)<0){
            nums.remove(i);
         }
         else{
            i++;
         }
      }
      System.out.println(nums);
   }