import java.util.ArrayList;
public class SwapTester{
   public static void swap(ArrayList<Double> array, int a, int b){
      double temp = array.get(a);
      array.set(a, b);
      array.set(b, temp);
   }

public static void main(String[] arg){
   ArrayList<Double> nums = new ArrayList<Double>();
   nums.add(43);
   nums.add(56);
   System.out.println(nums);
   swap(nums, 0, 1);
   System.out.println(nums);
}

public static void selectSort(ArrayList<Double> arg){
for(int i = 0; i < arg.size(); i++){
int min = i;
   for(int n = min + 1; n < arg.size(); n++){
   if(arg.get(min) > arg.get(n)){
      n = min;
   }
   swap(arg, min, i);
   }
   }
}
public static void insertSort(double[] temp){
   for(int i = 1; i < temp.length; i++){
   int index = 1;
   while(index>0 && temp[index] < temp[index-1]){
      swap(temp, index, index-1);
      index--;
   }
}
}
}