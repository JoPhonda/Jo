import java.util.*;
public class JuniorRecords{
   private ArrayList<Student> students;
   public JuniorRecords(){
      students = new ArrayList<Student>();
   }
   public void addStudent(Student s){
      students.add(s);
   }
   public void printAll(){
      System.out.println("All Students:");
      students.forEach(s -> System.out.println(s));
   }
   public void printJuniorMarshals(){
      System.out.println("Junior Marshals:");
      ArrayList<Student> marshals = students;
      for (int i = 0; i < marshals.size()-1; i++){
         for (int j = i+1; j < marshals.size(); j++){
         if (marshals.get(i).getGPA() < marshals.get(j).getGPA()){
            marshals.set(i, marshals.get(j));
         }
      }
      marshals.set(i, marshals.get(i));
   }
   for (Student m: marshals){
      
      for (int x = 0; x <= 10; x++){
         if ((x < 10)&&(m.getGPA() >= 3.75) && (m.getGPA() != marshals.get(m-1).getGPA())){
            System.out.println("#" + x + ": " + m);
         }
         else if ((x == 10) && m.getGPA() == marshals.get(m-1).getGPA()){
            System.out.println("#" + x + ": " + m);
         }
      }
   }
}
}