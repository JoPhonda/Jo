public class Student{
  private static String name;
  private static double gpa;
  public Student (String n, double g){
     name = n;
     gpa = g;
  }
  public String getName(){
     return name;
  }
  public double getGPA(){
     return gpa;
  }
  public String toString(){
     return name+", GPA: "+gpa;
  }
}