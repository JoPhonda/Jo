 //Joseph Kim P6
 /*"On my honor as a student, I have neither recieved nor given any unauthorized assistance on this assignment."*/

import java.util.*;

public class SimpleArithmetic
{
   public static void main(String[] arg)
   {
      Scanner input = new Scanner(System.in);
      System.out.println("Enter 5 integers.");
      int first = input.nextInt();
      int second = input.nextInt();
      int third = input.nextInt();
      int fourth = input.nextInt();
      int fifth = input.nextInt();
      int result1 = first + second;
      int result2 = result1 * third;
      int result3 = result2 - fourth;
      int result4 = result3 / fifth;
      System.out.println(first +" + "+ second +" = "+ result1);
      System.out.println(result1 +" * "+ third +" = "+ result2);
      System.out.println(result2 +" - "+ fourth +" = "+ result3);
      System.out.print(result3 +" / "+ fifth +" = "+ result4);
   }
}