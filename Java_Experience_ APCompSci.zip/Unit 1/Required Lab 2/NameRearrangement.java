 //Joseph Kim P6
 /*"On my honor as a student, I have neither recieved nor given any unauthorized assistance on this assignment."*/

import java.util.*;

public class NameRearrangement
{
   public static void main(String[] arg)
   {
      Scanner input = new Scanner(System.in);
      System.out.println("Enter a name in (first, middle, last) format:");
      String fullName = input.nextLine();
      int loc = fullName.indexOf(" ");
      String first = fullName.substring(0, loc);
      String middleAndLast = fullName.substring(loc+1);
      int loc2 = middleAndLast.indexOf(" ");
      String last = middleAndLast.substring(loc2+1);
      String middle = middleAndLast.substring(0, loc2);
      System.out.println("Initials:");
      String firstInitial = first.substring(0,1);
      String lastInitial = last.substring(0,1);
      String middleInitial = middle.substring(0,1);
      System.out.println(firstInitial + middleInitial + lastInitial);
      String rearranged = last + ", " + first + " " + middleInitial;
      System.out.println("Rearranged name:");
      System.out.println(rearranged);
      }
}