/**
 * The CoinSlot class models a single slot in a coin sorter that can take a certain 
 * type of coin. It keeps track of how many rolls were completed and how many coins 
 * are in the partially filled slot
 * @author Kimberly A. Baram, 11/10/2021
 * @version 1.1, revised to include number of completed rolls
 * @since 1.0
 */
public class CoinSlot{
   private int value, capacity, currentCoins, rollCompleted;
   
   /**
    * Constructs the slot based on the coin type and number of coins per roll
    * @param v the value in cents of a single coin
    * @param c the number of coins per roll
    */
   public CoinSlot(int v, int c){
      value = v;
      capacity = c;
      currentCoins = 0;
      rollCompleted = 0;
   }
   
   /**
    * Adds a coin to the slot. If doing so fills a roll, increments
    * the roll count and sets slot coins to 0.
    */
   public void drop(){
      currentCoins++;
      if(currentCoins == capacity){
      rollCompleted++;
      currentCoins = 0;
      }
   }
   
   /**
    * returns the value in cents of a full roll
    * @return the value in cents of  a full roll
    */
   public int getFullRollValue(){
      return value*capacity;
   }
   
   /**
    * Returns the cent value of all completed rolls
    * @return the total value in cents of all completed rolls
    */
   public int getRollsCompletedValue(){
      return rollCompleted*getFullRollValue();
   }
   
   /**
    * returns the value in cents of the coins currently in the slot
    * @return the value in cents of the coins currently in the slot
    */
   public int getCurrentSlotValue(){
      return currentCoins * value;
   }
   
   /**
    * returns a string describing the value of what has been rolled and what is left over
    * @return a string describing the value of what has been rolled and what is left over
    */
   public String toString(){
      int totalRolled = getRollsCompletedValue();
      return rollCompleted + " rolls, " + (totalRolled/100) + " dollars and " + (totalRolled%100) + " cents, and " + currentCoins + " extra coins.";
   }
   
}