public class APLine{
   private int a;
   private int b;
   private int c;
   public APLine(int a1, int b1, int c1){
   a = a1;
   b = b1;
   c = c1;
   }
   public double getSlope(){
   double slope = -(double)a/(double) b;
   return slope;
   }
   public boolean isOnLine(int x, int y){
   int lineValue = (a*x)+(b*y)+c;
   if (lineValue == 0){
   return true;
   }
   else{
   return false;
   }
   }
}