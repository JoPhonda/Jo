public class Elevator{
   private int topFloor;
   private int capacity;
   private int currentFloor;
   private int numberPassengers;
   public Elevator(int t, int c){
      topFloor = t;
      capacity = c;
      currentFloor = 1;
      numberPassengers = 0;
   }
   public String toString(){
      return "Floor: "+currentFloor+"\nPassengers: "+numberPassengers+"\n";
   }
   public void letOff(int n){
      numberPassengers -= n;
      if (numberPassengers < 0){
         numberPassengers = 0;
      }
   }
   public void letOn(int o){
      numberPassengers += o;
      if (numberPassengers > capacity){
         numberPassengers = capacity;
      }
   }
   public void moveUp(int u){
      currentFloor += u;
      if (currentFloor > topFloor){
         currentFloor = topFloor;
      }
   }
   public void moveDown(int d){
      currentFloor -= d;
      if (currentFloor < 0){
         currentFloor = 0;
      }
   }
}