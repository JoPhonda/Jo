public class Spinner{
   private static String message;
   public static int spin(){
      int r = (int)(Math.random()*7)+1;
      if (r == 1){
         message = "Take 1 cherry from the tree";
         return 1;
      }
      else if (r == 2){
         message = "Take 2 cherries from the tree";
         return 2;
      }
      else if (r == 3){
         message = "Take 3 cherries from the tree";
         return 3;
      }
      else if (r == 4){
         message = "Take 4 cherries from the tree";
         return 4;
      }
      else if (r == 5){
         message = "Oh no, a dog has come and eaten some of your cherries. Put 3 cherries back on your tree";
         return -3;
      }
      else if (r == 6){
         message = "Oh no, a bird has come and eaten some of your cherries. Put 2 cherries back on your tree";
         return -2;
      }
      else{
         message = "Oh no, your basket spilled! Put all of your cherries back on your tree";
         return -10;
      }
   }
   public static String getMessage(){
      return message;
   }
}