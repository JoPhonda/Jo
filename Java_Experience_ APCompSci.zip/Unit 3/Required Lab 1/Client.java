public class Client{
   public static void main(String[] arg){
      Player p1 = new Player("Tweedle Dee");
      Player p2 = new Player("Tweedle Dum");
      System.out.println("Player 1: "+p1.getName());
      System.out.println("Player 2: "+p2.getName());
      while ((p1.hasWon() != true)&&(p2.hasWon() != true)){
         int cherries = Spinner.spin();
         p1.updateTree(cherries);
         p1.updateBucket(cherries);
         System.out.println("\n"+p1.getName()+" spins: "+Spinner.getMessage());
         System.out.println("Tree cherries: "+p1.getTree());
         System.out.println("Bucket cherries: "+p1.getBucket());
         
         int cherries2 = Spinner.spin();
         p2.updateTree(cherries2);
         p2.updateBucket(cherries2);
         System.out.println("\n"+p2.getName()+" spins: "+Spinner.getMessage());
         System.out.println("Tree cherries: "+p2.getTree());
         System.out.println("Bucket cherries: "+p2.getBucket());
      }
      if (p1.hasWon()){
         System.out.print("\n"+p1.getName()+" wins!");
      }
      else{
         System.out.print("\n"+p2.getName()+" wins!");
      }
   }
}