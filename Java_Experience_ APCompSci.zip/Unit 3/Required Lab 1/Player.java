public class Player{
   private String name;
   private int treeCherries;
   private int bucketCherries;
   public Player(String n){
      treeCherries = 10;
      bucketCherries = 0;
      name = n;
   }
   public String getName(){
      return name;
   }
   public int getTree(){
      return treeCherries;
   }
   public int getBucket(){
      return bucketCherries;
   }
   public boolean hasWon(){
      if(getBucket() == 10){
         return true;
      }
      else{
         return false;
      }
   }
   public void updateTree(int num){
      treeCherries -= num;
      if (treeCherries < 0){
         treeCherries = 0;
      }
      else if (treeCherries > 10){
         treeCherries = 10;
      }
   }
   public void updateBucket(int num){
      bucketCherries += num;
      if (bucketCherries < 0){
         bucketCherries = 0;
      }
      else if (bucketCherries > 10){
         bucketCherries = 10;
      }
   }
}