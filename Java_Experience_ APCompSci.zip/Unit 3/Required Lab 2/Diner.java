public class Diner{
   private String name = "";
   Meal dinerMeal;
   public void setName(String n){
      name = n;
      dinerMeal = new Meal();
   }
   public String getName(){
      return name;
   }
   public void callSetStarter(int s){
      dinerMeal.setStarter(s);
   }
   public void callSetEntree(int e){
      dinerMeal.setEntree(e);
   }
   public void callSetDessert(int d){
      dinerMeal.setDessert(d);
   }
   public double getPrice(){
      return dinerMeal.getPrice();
   }
   public String toString(Course a){
      return a.toString();
   }
}