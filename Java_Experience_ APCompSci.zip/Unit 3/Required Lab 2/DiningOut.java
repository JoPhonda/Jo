/**
 * The DiningOut class simulates ordering a meal for two diners. Each diner has a suggested meal and then has the option to change out the courses.
 * After both diners have "locked in" their meal choices, a detailed check is printed with the items ordered and pricing.
 * @author kabaram
 * @version 1.0
 */

import java.text.*;
import java.util.*;

public class DiningOut{
   private static Scanner input = new Scanner(System.in); //allows for console input
   private static NumberFormat currency = NumberFormat.getCurrencyInstance(); //allows doubles to be printed in money format


   /**
    * Shows the initially created meal for the current diner and provides the option to switch out any of the courses.
    * @param d the Diner to select their meal
    */
   public static void setMeal(Diner d){
      System.out.println("\nHello " + d.getName() + ", here is a suggested meal for you.");
      System.out.println(d.getMeal());
      
      //allow changes until the user enters 2
      while (true){
         System.out.println("\nWould you like to make changes? 1 - yes, 2 - no");
         int choice = input.nextInt();
         if (choice == 2){
            break;
         }
         System.out.println("1 - Change starter");
         System.out.println("2 - Change entree");
         System.out.println("3 - Change dessert");
         choice = input.nextInt();
         
         //show course choices depending on which course the diner chooses to change
         switch (choice){
            case 1: System.out.println("\nHere are the starter options. Enter the one you would like");
               Course.printStarters();
               choice = input.nextInt();
               d.setStarter(choice);
               break; //exits the switch block
            case 2: System.out.println("\nHere are the entree options. Enter the one you would like");
               Course.printEntrees();
               choice = input.nextInt();
               d.setEntree(choice);
               break;
            default: System.out.println("\nHere are the dessert options. Enter the one you would like");
               Course.printDesserts();
               choice = input.nextInt();
               d.setDessert(choice);  
         } //end switch
         System.out.println("\nHere is your updated meal, " + d.getName());
         System.out.println(d.getMeal());
      }//end while
   
   }

   /**
    * Instantiates two diners, sets their meals, and prints out their final check.
    * @param args not used
    */
   public static void main(String[] args){
      Diner d1 = new Diner("Maggie");
      Diner d2 = new Diner("May");
      setMeal(d1);
      setMeal(d2);
      System.out.println("\n\n\nMEAL CHARGES:");
      System.out.println(d1 + "\n");
      System.out.println(d2 + "\n");
      double subtotal = d1.getPrice() + d2.getPrice();
      System.out.println("Subtotal: " + currency.format(subtotal));
      double tax = (d1.getPrice() + d2.getPrice()) * .04;
      System.out.println("4% Sales Tax: " + currency.format(tax));
      double tip = (d1.getPrice() + d2.getPrice()) * .18;
      System.out.println("18% Hospitality Fee: " + currency.format(tip));
      double total = subtotal + tax + tip;
      System.out.println("GRAND TOTAL: " + currency.format(total));
   
   }

}
