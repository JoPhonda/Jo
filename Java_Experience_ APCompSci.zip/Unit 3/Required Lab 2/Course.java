/**
  *  The Course class models one of three courses of a restaurant meal. A course can be a starter, an entree, or a dessert.
  *  Each course has a pre-set price associated with it. The course class also stores all information on menu items available,
  *  sorted by course category, with their prices.
  *  @author kabaram
  *  @version 1.0
  */

import java.text.*; //allows the NumberFormat class to be used (in this case, for currency)

public class Course{

  //starters and prices
   private static final String[] starters = {"Calamari", "Shrimp & Eggplant", "Carpaccio", "Spinach & Artichoke Dip", "Tomato Caprese"};
   private static final double[] starterPrices = {7.99, 10.49, 9.99, 6.99, 5.99};
   
   //entrees and prices
   private static final String[] entrees = {"Bolognese", "Rigatoni", "Lasagna", "Veggie Flatbread", "Meat Flatbread"};
   private static final double[] entreePrices = {14.99, 14.99, 14.99, 12.99, 12.99};
   
   //desserts and prices
   private static final String[] desserts = {"Tiramisu", "Chocolate Cake", "Gelato", "Cheesecake"};
   private static final double[] dessertPrices = {7.99, 8.99, 5.99, 8.99};
   
   //allows doubles to be formatted as money
   private static NumberFormat currency = NumberFormat.getCurrencyInstance();

   
   private int type; //1 = starter, 2 = entree, 3 = dessert
   private String name; //item name (one of the elements from the string array corresponding with the type)
   private double price; //item price (one of the elements from the double array corresponding with the type)
   
   /**
     * Creates a course of the specified type, with a randomized item and its associated price.
     * Precondition: type equals 1, 2, or 3
     * @param type the type of entree to be created
     */
   public Course(int type){
      this.type = type;
      int index;
      
      //Generate a random index from the course and price arrays
      //depending on the course's type
      switch (type){
         case 1: index = (int)(Math.random() * 5); //if type == 1, i.e. the type is a starter
            name = starters[index];
            price = starterPrices[index];
            break; //end switch
         case 2: index = (int)(Math.random() * 5);
            name = entrees[index];
            price = entreePrices[index];
            break;
         default: index = (int)(Math.random() * 4); //if type is neither 1 nor 2, it is a dessert
            name = desserts[index];
            price = dessertPrices[index];
      }
   }
   
   /**
    * @return a string respresentation of the course type
    */
   public String getType(){
      switch (type){
         case 1: 
            return "Starter";
         case 2: 
            return "Entree";
         default: 
            return "Dessert";
      }
   }
   
   /**
    * @return the name of the course
    */
   public String getName(){
      return name;
   }
   
   /**
    * @return the price of the course
    */
   public double getPrice(){
      return price;
   }
   
   /**
    * Prints all starters and their associated prices
    */
   public static void printStarters(){
      for (int i = 0; i < starters.length; i++){
         System.out.println((i + 1) + ". " + starters[i] + ", " + currency.format(starterPrices[i])); //currency.format produces a string representation of a double as money
      }
   }
   
    /**
    * Prints all entrees and their associated prices
    */     
   public static void printEntrees(){
      for (int i = 0; i < entrees.length; i++){
         System.out.println((i + 1) + ". " + entrees[i] + ", " + currency.format(entreePrices[i]));
      }
   }
   
   /**
    * Prints all desserts and their associated prices
    */
   public static void printDesserts(){
      for (int i = 0; i < desserts.length; i++){
         System.out.println((i + 1) + ". " + desserts[i] + ", $" + currency.format(dessertPrices[i]));
      }
   }
   
  /**
   * Changes the course name and associated price according to the number given.
   * Precondition: 1 <= index <= the length of the corresponding course array
   * @param index, the number associated with the chosen course; value is one more than the index in its array
   */
   public void setCourse(int index){
      switch (type){
         case 1: name = starters[index - 1]; //index - 1 because array indexing begins at 0 and menu choices begin at 1
            price = starterPrices[index - 1];
            break;
         
         case 2: name = entrees[index - 1];
            price = entreePrices[index - 1];
            break;
         default: name = desserts[index - 1];
            price = dessertPrices[index - 1];    
      }
   }
   
   /**
    * @return a string representation of the course, describing the name and price
    */
   public String toString(){
      String retVal;
      switch(type){
         case 1: retVal = "Starter: ";
            break;
         case 2: retVal = "Entree: ";
            break;
         default: retVal = "Dessert: ";
      }
      return retVal + name + ", Price: " + currency.format(price);
   }
}