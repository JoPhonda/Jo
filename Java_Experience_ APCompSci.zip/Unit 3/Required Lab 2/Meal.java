import java.text.*;
public class Meal{
   private static NumberFormat currency = NumberFormat.getCurrencyInstance();
   private double price;
   private Course starter, entree, dessert;
   public Meal(){
      starter = new Course(1);
      entree = new Course(2);
      dessert = new Course(3);
      setPrice();
   }
   public double getStarter(){
      return starter.getPrice();
   }
   public double getEntree(){
      return entree.getPrice();
   }
   public double getDessert(){
      return dessert.getPrice();
   }
   public double getPrice(){
      return price;
   }
   public void setStarter(int s){
      starter.setCourse(s);
   }
   public void setEntree(int e){
      entree.setCourse(e);
   }
   public void setDessert(int d){
      dessert.setCourse(d);
   }
   private void setPrice(){
      price = (getStarter() + getEntree() + getDessert())*0.9;
   }
   public String toString(Course a){
      return a.toString();
   }
}