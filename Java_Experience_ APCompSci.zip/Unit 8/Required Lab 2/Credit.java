import java.util.*;
public class Credit{
   public static void interest(int c, int p, int m){
      int newBal = (c-p)+((c-p)/50);
      System.out.println("Month "+m+" balance: $"+c);
      if (newBal > 0){
         System.out.println("New balance with 2% interest after monthly payment of $"+p+": "+newBal+"\n");
         interest (newBal, p, m+1);
      }
      else{
         System.out.println(m+" months to pay off debt");
      }
   }
   public static void main(String[] arg){
      Scanner input = new Scanner(System.in);
      System.out.println("Enter charge:");
      int charge = input.nextInt();
      Scanner input2 = new Scanner(System.in);
      System.out.println("Enter monthly payment:");
      int monthly = input.nextInt();
      interest(charge, monthly, 1);
   }
}