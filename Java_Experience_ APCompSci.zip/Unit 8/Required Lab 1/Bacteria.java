import java.util.*;
public class Bacteria{
   public static int multiply(int b, int h){
      if (h != 0){
         return 5*multiply(b, h-1);
      }
      return b;
   }
   public static void main(String[] arg){
      Scanner input = new Scanner(System.in);
      System.out.println("How many bacteria were left on the classroom door?");
      int bacteria = input.nextInt();
      Scanner input2 = new Scanner(System.in);
      System.out.println("How many hours passed before the doorknob was cleaned?");
      int hours = input.nextInt();
      System.out.println("There were "+multiply(bacteria, hours)+" bacteria on the doorknob at the time of cleaning.");

   }
}