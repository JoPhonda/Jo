public class FibTest{
   public static int fib(int n){
      if(n <= 2){
         return 1;
      }
      return fib(n-2) + fib(n-1);
   }
   public static void main(String[] args){
      long startTime = System.nanoTime();
      fib(57);
      long endTime = System.nanoTime();
      System.out.println(((endTime-startTime)/1000000000.0)+" seconds");
   }
}