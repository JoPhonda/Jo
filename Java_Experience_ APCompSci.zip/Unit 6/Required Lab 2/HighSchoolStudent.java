public class HighSchoolStudent implements Gradeable{
   public double totalGrades;
   public int numberGrades;
   public void updateGrade(){
      int temp = (int)(Math.random()*71+30);
      if (temp < 50){
         temp = 50;
      }
      numberGrades++;
      totalGrades += temp;
   }
   public String getScore(){
      return (totalGrades/numberGrades)+"%";
   }
   public boolean isPassing(){
      if ((totalGrades/numberGrades) >= 63.5){
         return true;
      }
      return false;
   }
}