public interface Gradeable{

   void updateGrade();

   String getScore();

   boolean isPassing();

}