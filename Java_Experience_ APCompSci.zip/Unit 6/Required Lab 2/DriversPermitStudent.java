public class DriversPermitStudent implements Gradeable{
   public int driversPoints = 100;
   public void updateGrade(){
      driversPoints -= 4;
   }
   public String getScore(){
      return driversPoints+"%";
   }
   public boolean isPassing(){
      if (driversPoints >= 80){
         return true;
      }
      return false;
   }
}