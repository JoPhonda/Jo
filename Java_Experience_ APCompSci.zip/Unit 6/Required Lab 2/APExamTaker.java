public class APExamTaker implements Gradeable{
   public int rawScore;
   public void updateGrade(){
      rawScore++;
   }
   public String getScore(){
      if(rawScore >= 61){
         return "5";
      }
      else if (rawScore >= 46){
         return "4";
      }
      else if (rawScore >= 36){
         return "3";
      }
      else if (rawScore >= 28){
         return "2";
      }
      else{
         return "1";
      }
   }
   public boolean isPassing(){
      if (rawScore >=36){
         return true;
      }
      return false;
   }
}