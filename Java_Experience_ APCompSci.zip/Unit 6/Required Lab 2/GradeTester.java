public class GradeTester{
   public static void main(String[] arg){
      for (int i = 0; i < 20; i++){
         int random = (int)(Math.random()*3+1);
         if(random == 1){
            Gradeable a = new HighSchoolStudent();
            int random1 = (int)(Math.random()*20+1);
            for (int j = 0; j < random1; j++){
               a.updateGrade();
            }
            System.out.println("Type: High School Average Grade");
            System.out.println("Score: "+a.getScore());
            System.out.println("Pass: "+a.isPassing()+"\n");
         }
         else if(random == 2){
            Gradeable a = new APExamTaker();
            int random1 = (int)(Math.random()*66+15);
            for (int j = 0; j < random1; j++){
               a.updateGrade();
            }
            System.out.println("Type: AP Exam Score");
            System.out.println("Score: "+a.getScore());
            System.out.println("Pass: "+a.isPassing()+"\n");
         }
         else{
            Gradeable a = new DriversPermitStudent();
            int random1 = (int)(Math.random()*14)-1;
            for (int j = 0; j < random1; j++){
               a.updateGrade();
            }
            System.out.println("Type: Drivers Permit Score");
            System.out.println("Score: "+a.getScore());
            System.out.println("Pass: "+a.isPassing()+"\n");
         }
      }
   }
}