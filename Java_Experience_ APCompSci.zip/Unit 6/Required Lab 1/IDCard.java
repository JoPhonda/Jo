public class IDCard extends Card{
   private static int issueDate, expirationDate;
   public IDCard(String h, String i, int n, int issue, int expire){
      super(h, i, n);
      issueDate = issue;
      expirationDate = expire;
   }
   public int getIssueDate(){
      return issueDate;
   }
   public int getExpirationDate(){
      return expirationDate;
   }
   public boolean isExpired(){
      return 2023>getExpirationDate();
   }
   public String toString(){
      return super.toString()+"\nIssue Date: "+getIssueDate()+"\nExpiration Date: "+getExpirationDate();
   }
}