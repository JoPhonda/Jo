public class DebitCard extends CreditCard{
   private static int pin;
   public DebitCard(String h, String i, int n, int b, int expire, int p){
      super(h, i, n, b, expire);
      pin = p;
   }
  public int getPin(){
     return pin;
  }
  public String toString(){
     return super.toString()+"\nPIN: "+getPin();
  } 
}