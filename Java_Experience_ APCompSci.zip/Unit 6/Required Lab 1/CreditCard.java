public class CreditCard extends Card{
   private static int balance, expirationDate;
   public CreditCard(String h, String i, int n, int b, int expire){
      super(h, i, n);
      balance = b;
      expirationDate = expire;
   }
   public int getBalance(){
      return balance;
   }
   public int getExpirationDate(){
      return expirationDate;
   }
   public boolean isExpired(){
      return 2023>getExpirationDate();
   }
   public String toString(){
      return super.toString()+"\nBalance: "+getBalance()+"\nExpiration Date: "+getExpirationDate();
   }
}