public class DriversLicence extends IDCard{
   private static int age;
   private static String donorStatus;
   public DriversLicence(String h, String i, int n, int issue, int expire, int a, String d){
      super(h, i, n, issue, expire);
      age = a;
      donorStatus = d;
   }
   public int getAge(){
      return age;
   }
   public String getDonorStatus(){
      return donorStatus;
   }
   public String toString(){
      return super.toString()+"\nAge: "+getAge()+"\nDonor Status: "+getDonorStatus();
   }
}