public class LibraryCard extends Card{
   private static int numberItemsChecked;
   public LibraryCard(String h, String i, int n, int c){
      super(h, i, n);
      numberItemsChecked = c;
   }
   public int getChecked(){
      return numberItemsChecked;
   }
   public String toString(){
      return super.toString()+"\nNumber Items Checked: "+getChecked();
   }
}