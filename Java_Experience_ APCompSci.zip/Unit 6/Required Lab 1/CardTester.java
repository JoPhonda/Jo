public class CardTester{
   public static void main(String[] arg){
      Card c = new Card("Joseph", "Generic Company", 1234567890);
      System.out.println("Card\n"+c);
      
      Card i = new IDCard("Parmit", "Apple", 987654321, 2018, 2022);
      System.out.println("\nID Card\n"+i);
      
      Card d = new DriversLicence("Parmit", "DMV", 1234, 2023, 2026, 16, "N");
      System.out.println("\nDrivers Licence\n"+d);
      
      Card l = new LibraryCard("Joseph", "Fairfax Library", 5678, 4);
      System.out.println("\nLibrary Card\n"+l);
      
      Card cc = new CreditCard("Jeff Bezos", "Visa", 11111, 1000000000, 2045);
      System.out.println("\nCredit Card\n"+cc);
      
      Card dd = new DebitCard("Jeff Barnos", "Visa", 7890, 12, 2021, 1234);
      System.out.println("\nDebit Card\n"+dd);
      
      Card[] cardArray = new Card[6];
      cardArray[0] = c;
      cardArray[1] = i;
      cardArray[2] = d;
      cardArray[3] = l;
      cardArray[4] = cc;
      cardArray[5] = dd;
      System.out.println("\nEXPIRED CARDS\n"+dd);
      for (Card x: cardArray){
         if (x.isExpired()){
            System.out.println("\n"+x);
         }
      }
   }
}