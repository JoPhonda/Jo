public class Card{
   private static String holder, issuer;
   private static int number;
   public boolean isExpired(){
      return false;
   }
   public Card(String h, String i, int n){
      holder = h;
      issuer = i;
      number = n;
   }
   public String getHolder(){
      return holder;
   }
   public String getIssuer(){
      return issuer;
   }
   public int getNumber(){
      return number;
   }
   public String toString(){
      return "Holder: "+getHolder()+"\nIssuer: "+getIssuer()+"\nNumber: "+getNumber();
   }
}