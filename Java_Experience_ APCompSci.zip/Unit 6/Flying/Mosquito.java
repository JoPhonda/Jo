public class Mosquito implements Volant{
   public void takeOff(){
      System.out.println("initialting take off.");
   }
   public void land(){
      System.out.println("landing.");
   }
   public void cruise(){
      System.out.println("searching...");
   }
   public void beAnnoying(){
      System.out.println("BZZZZZZZZZ");
   }
}