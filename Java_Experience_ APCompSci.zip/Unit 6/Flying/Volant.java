public interface Volant{
   void takeOff();
   void land();
   void cruise();
}