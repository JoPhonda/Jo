public class VolantTester{
   public static void main(String[] arg){
      Volant[] flyingThings = new Volant[2];
      Nosquito bob = new Mosquito();
      Jet blue = new Jet();
      bob.beAnnoying();
      flyingThings[0] = bob;
      flyingThings[1] = blue;
      // flyingThings[0].beAnnoying();
      
   }
}