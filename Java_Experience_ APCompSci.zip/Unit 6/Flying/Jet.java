public class Jet implements Volant{
   public void takeOff(){
      System.out.println("Initiating flight.");
   }
   public void land(){
      System.out.println("Landing.");
   }
   public void cruise(){
      System.out.println("Searching...");
   }
}