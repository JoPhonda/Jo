public class Vehicle{
   private static int passengers;
   private static String name;
   public Vehicle(int p, String n){
      passengers = p;
      name = n;
   }
   public String getName(){
      return name;
   }
   public int getPassengers(){
      return passengers;
   }
   public String toString(){
      return "Passengers: "+passengers+" Name: "+name;
   }
}