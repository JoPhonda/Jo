public class Car extends Vehicle{
   private int odometer;
   public Car(int o){
      super(5, "sedan");
      odometer = o;
   }
   public int getOdometer(){
      return odometer;
   }
   public void driveAMile(){
      odometer++;
   }
   public String toString(){
      return super.toString();
   }
}