public class ShapeTester{
   public static void main(String[] arg){
      Circle x = new Circle(3);
      Shape a = new Circle(5);
   }
}