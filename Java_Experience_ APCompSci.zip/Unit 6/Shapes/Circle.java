public class Circle extends Shape{
   private double radius;
   public Circle(double r){
      super("circle");
      radius = r;
   }
   public double getArea(){
      return Math.PI * Math.pow(radius, 2);
   }
   public String toString(){
   return super.toString()+" It has an area of "+getArea();
   }
}