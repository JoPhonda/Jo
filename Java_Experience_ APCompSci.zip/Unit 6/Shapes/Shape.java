public abstract class Shape
{
   private String name;
   public Shape(String n){
      name = n;
   }
   public String getName(){
      return name;
   }
   public abstract double getArea();
   public String toString(){
      return "This shape is a "+name+".";
   }
}