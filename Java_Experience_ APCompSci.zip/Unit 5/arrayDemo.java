public class arrayDemo{

   public static int getMaxIndex(int arr[]){
      int maxIndex = arr[0];
      for (int i = 1; i < arr.length;i++){
         if(arr[i] > maxIndex){
            maxIndex = i;
         }
      }
      return maxIndex;
   }
   public static void main(String[] arg){
      int[] array1 = {45, 85, 23, 10, 19};
      System.out.print(getMaxIndex(array1));
   }
}