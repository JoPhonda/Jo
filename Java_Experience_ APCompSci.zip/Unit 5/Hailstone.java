class Hailstone{
   private int number;
   public void randomize(){
      number = (int)(Math.random()*100)+1;
   }
   public void int setNumber(int s){
      number = s;
      doSequence();
   }
   public int getNumber(){
      return number;
   }
   public void doSequence(){
      number *=3;
      if (number % 2 == 0){
         number /= 2;
      }
      else{
         number += 1;
      }
   }
   public String toString(){
      return "Value: "+number;
   }
}