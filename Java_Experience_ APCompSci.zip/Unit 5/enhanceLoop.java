public class enhanceLoop
{
   public static void main(String[] arg)
   {
      public boolean allSame(Die[] dice){
      int num = dice[0].getValue();
         for(Die d :dice){
            if(d.getValue() != num){
               return false;
            }
            return true;
         }
      }
   }
}