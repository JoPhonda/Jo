class HailstoneTester{
   int[5] hailstones = new Hailstone();
   randomize();
   hailstones[0] = getNumber();
   for (int i = 1; i < hailstones.length; i++){
      hailstones[i] = hailstones[i-1];
   }
   for (int i = 0; i < hailstones.length; i++){
      System.out.println(hailstones[i]);
   }
   for (int i = 1; i < hailstones.length; i++){
      setNumber(i-1);
      hailstones[i] = getNumber();
   }
   for (int i = 0; i < hailstones.length; i++){
      System.out.println(hailstones[i]);
   }
}