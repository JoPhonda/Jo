public class MyObjectTester{
   public static MyObject[] buildArray(){
      MyObject[] sam = new MyObject[5];
      for(int i = 0; i < sam.length; i++){
         sam[i] = new MyObject();
      }
      return sam;
   }
   public static void printArray(MyObject[] temp){
   System.out.print("[");
      for(int i = 0; i < temp.length; i++){
         System.out.print(temp[i] + " ");
      }
   System.out.println("J");
   }
   public static void incrementArray(MyObject[] bob){
      for(int i = 0; i < bob.length; i++){
         bob[i].increment();
      }
   }
   public static void main (String[] arg){
      MyObject[] objectArray = buildArray();
      printArray(objectArray);
      incrementArray(objectArray);
      printArray(objectArray);
   }
}