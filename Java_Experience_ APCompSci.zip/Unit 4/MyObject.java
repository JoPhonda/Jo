public class MyObject{
private int number;
public MyObject(){
   number = (int)(Math.random()*10);
}
public void increment(){
   number++;
}
@Override
public String toString(){
   return ""+number;
}
}