/**
* The SegregatedBinary class creates a randomly generated array of 0's and 1's,
* then segregates the 0's to the left side of the array and the 1's to the right.
* @author Kimberly A. Baram
* @version 1.0
*/
public class SegregatedBinary{

/**
  * Builds and returns an array with a random number of elements
  * (between 10 and 20, inclusive), filled with randomly
  * generated 0's and 1's
  * @return The randomly generated array
  */
   public static int[] buildArray(){
      int numberElements = (int)(Math.random()*11)+10;
      int[] randomArray = new int[numberElements];
      for (int i = 0; i < numberElements; i++){
         randomArray[i] = (int)(Math.random()*2);
      }
      return randomArray;
   }

/**
  * Prints the contents of the passed array.
  * @param arr the array to be printed.
  */
   public static void printArray(int[] arr){
      System.out.print("{");
      for (int i = 0; i < arr.length; i++){
         System.out.print(arr[i]);
         if (i != (arr.length - 1)){
            System.out.print(", ");
         }
      }
      System.out.println("}");
   }

/**
  * Counts and returns the number of zeros in the passed array.
  * @param arr the array to count zeros
  * @return the number of zeros
  */
   public static int countZeros(int[] arr){
      int numberZeroes = 0;
      for (int i = 0; i < arr.length; i++){
         if(arr[i] == 0){
            numberZeroes += 1;
         }
      }
      return numberZeroes;
   }

/**
  * Builds and returns a NEW array containing the same number of one's and
  * zero's as the original, but with the 0's to the left and the 1's to the right.
  * Example: if arr contains {0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0}
  * then the returned array is {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1}
  * @param the array on which the returned array is based
  * @return a new array with the 0's and 1's segregated
  */
   public static int[] rearrange(int[] arr){
      int numberOfZeroes = countZeros(arr);
      int[] arranged = new int[arr.length];
      for (int i = 0; i < numberOfZeroes; i++){
         arranged[i] = 0;
      }
      for (int i = numberOfZeroes; i < arranged.length; i++){
         arranged[i] = 1;
      }
      return arranged;  //temporary return value so that this template compiles
   }

/**
  * Prints the numbers of zeros and ones contained in the passed array.
  * Example: if arr contains {0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0}
  * Then the following is printed:
  *     Zeros: 10
  *     Ones: 6
  * @param arr the array from which to count the ones and zeros
  */
   public static void printNumOfEach(int[] arr){
      int numberOfZeros = countZeros(arr);
      int numberOfOnes = arr.length - numberOfZeros;
      System.out.println("Zeroes: "+numberOfZeros);
      System.out.println("Ones: "+numberOfOnes);
   }

/**
  * Test the methods written above.
  * @param args not used
  */
   public static void main(String[] args){
      int[] arr = buildArray();
      int[] rearranged = rearrange(arr);
      System.out.println("Original array:");
      printArray(arr);
      printNumOfEach(arr);
      System.out.println("\nSegregated array:");
      printArray(rearranged);
   }
}