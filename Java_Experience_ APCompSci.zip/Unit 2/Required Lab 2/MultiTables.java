//Joseph Kim P6
/*"On my honor as a student, I have neither recieved nor given any unauthorized assistance on this assignment."*/
import java.util.*;

public class MultiTables
{
   public static void main(String[] arg)
   {
      boolean test = true;
      while (test){
      Scanner input =new Scanner(System.in);
      System.out.println("Enter a number (0 to exit):");
      int num = input.nextInt();
         if (num == 0){
            test = false;
         }
         else{
            System.out.println("Multiplication table for "+num+":");
            if(num > 0){
               for(int i = 0; i <= num; i++){
                  int sum = num * i;
                  System.out.println(num+" x "+i+" = "+sum);
               }
            }
            else{
               for(int i = 0; i >= num; i--){
                  int pos = -1 * i;
                  int sum = num * pos;
                  System.out.println(num+" x "+pos+" = "+sum);
               }
            }
         }
      }
      System.out.print("See ya!");
   }
}