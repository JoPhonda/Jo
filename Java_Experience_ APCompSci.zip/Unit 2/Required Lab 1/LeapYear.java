//Joseph Kim P6
/*"On my honor as a student, I have neither recieved nor given any unauthorized assistance on this assignment."*/
import java.util.*;

public class LeapYear
{
   public static void main(String[] arg)
   {
      Scanner input = new Scanner(System.in);
      System.out.println("Enter a year.");
      int year = input.nextInt();
      if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)){
         System.out.print(year + " is a leap year.");
      }
      else{
         System.out.print(year + " is not a leap year. The closest leap year is ");
         if(year % 4 == 1){
            int subyear = year - 1;
            System.out.print(subyear);
         }
         else if(year % 4 == 3){
            int subyear = year + 1;
            System.out.print(subyear);
         }
         else if(year % 4 == 2){
            int random = (int)(Math.random()*2);
            if (random == 1){
               int subyear = year + 2;
               System.out.print(subyear);
            }
            else if (random == 0){
               int subyear = year - 2;
               System.out.print(subyear);
            }
         }
      }
   }
}

//doesn't handle finding closest leap year for 2000, or 2101