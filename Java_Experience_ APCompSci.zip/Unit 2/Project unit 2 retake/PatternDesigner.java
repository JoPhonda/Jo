//Joseph Kim P6
/*"On my honor as a student, I have neither recieved nor given any unauthorized assistance on this assignment."*/
import java.util.*;

public class PatternDesigner
{
   public static void main(String[] arg)
   {
      System.out.println("--- Pattern Designer ---");
      boolean test = true;
      while (test){
         Scanner input =new Scanner(System.in);
         System.out.println("Enter 1 to make a mirrored rhombus.\nEnter 2 to make a pyramid.\nEnter 3 to make a half diamond.\nEnter 4 to make an eight.\nEnter 5 to exit.");
         int num = input.nextInt();
         if (num == 5){
            test = false;
         }
         else if ((num >=1) && (num <=4)){
         boolean test2 = true;
            System.out.println("Enter the character for your design.");
            input.nextLine();
            String character = input.nextLine();
            character = character.substring(0,1);
            while (test2){
            System.out.println("Enter the number of rows (odd number, minimum 5).");
            int rows = input.nextInt();
               if((rows%2) == 0){
                  System.out.println("Please enter an odd number.");
               }
               else if(rows < 5){
                  System.out.println("Please enter a number greater than 5.");
               }
               else{
                  System.out.println("Here is your pattern:");
                  if(num == 1){
                 for(int i = 0; i <= rows; i++){
                     for(int j = 0; j < i; j++){
                        System.out.print(" ");
                     }
                     for(int k = 0; k < rows; k++){
                        System.out.print(character);
                     }
                     System.out.println();
                     }  
                  }
                  if(num == 2){
                     for(int i = 0; i<rows; i++){
                     System.out.println();
                     int newRow = (2*i)+1;
                        for(int j = rows-1; j > i; j--){
                           System.out.print(" ");
                        }
                        for(int k = 0; k < newRow; k++){
                           System.out.print(character);
                        }
                     }
                     System.out.println();
                  }
                  if(num == 3){
                  System.out.println();
                  int newRow = (rows + 1)/2;
                     for(int i = 0; i < newRow; i++){
                        for(int j = 0; j < i; j++){
                           System.out.print(character);
                        }
                        System.out.println();
                     }
                     for(int i = 0; i < newRow; i++){
                        System.out.print(character);
                     }
                     System.out.println();
                     for(int i = newRow-1; i > 0; i --){
                        for(int j = i; j > 0; j--){
                           System.out.print(character);
                        }
                        System.out.println();
                     }
                  }
                  if(num == 4){
                     int side = (rows - 3)/2;
                     
                     System.out.print(" ");
                     for(int i = 0; i < side; i++){
                        System.out.print(character);
                     }
                     System.out.println();
                     
                     for (int i = 0; i < side; i++){
                     System.out.print(character);
                        for(int j = 0; j < side; j++){
                        System.out.print(" ");
                        }
                     System.out.print(character);
                     System.out.println();
                     }
                     
                     System.out.print(" ");
                     for(int i = 0; i < side; i++){
                        System.out.print(character);
                     }
                     System.out.println();
                     
                     for (int i = 0; i < side; i++){
                     System.out.print(character);
                        for(int j = 0; j < side; j++){
                        System.out.print(" ");
                        }
                     System.out.print(character);
                     System.out.println();
                     }
                     
                     System.out.print(" ");
                     for(int i = 0; i < side; i++){
                        System.out.print(character);
                     }
                  }
                  System.out.println();
                  test2 = false;
               }
            }
         }
         else{
            System.out.println("Please choose a value between 1 and 5.");
         }
      }
      System.out.print("Thank you for using the pattern designer.");
   }
}