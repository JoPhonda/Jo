import java.util.ArrayList;
import java.util.Scanner;

public class TicTacToePro {

   private static ArrayList<String> board = new ArrayList<String>();
   private static String player = "X";
   private static int turn = 1;

   private static void initBoard() {
      for (int i = 0; i < 9; i++) {
         board.add(String.valueOf("*"));
      }
   }
   
   private static void printBoard() {
      for (int i = 0; i < 3; i++) {
         for (int j = 0; j < 3; j++) {
            System.out.print(board.get(i*3+j) + " ");
         }
         System.out.println();
      }
   }
   
   private static void choose() {
      Scanner scanner = new Scanner(System.in);
      System.out.println("Player " + player + ", choose a spot (1-9):");
      int spot = scanner.nextInt();
      if (board.get(spot-1).equals("X") || board.get(spot-1).equals("O")) {
         System.out.println("Spot already taken, choose again.");
         choose();
      } else {
         board.set(spot-1, player);
      }
   }

   private static void changePlayer() {
      player = player.equals("X") ? "O" : "X";
   }

   private static boolean checkWin() {
   // checks rows
      for (int i = 0; i < 9; i += 3) {
         if (board.get(i).equals(player) && board.get(i+1).equals(player) && board.get(i+2).equals(player)) {
            return true;
         }
      }
   // checks columns
      for (int i = 0; i < 3; i++) {
         if (board.get(i).equals(player) && board.get(i+3).equals(player) && board.get(i+6).equals(player)) {
            return true;
         }
      }
   // checks diagonals
      if (board.get(0).equals(player) && board.get(4).equals(player) && board.get(8).equals(player)) {
         return true;
      }
      if (board.get(2).equals(player) && board.get(4).equals(player) && board.get(6).equals(player)) {
         return true;
      }
      return false;
   }


   private static void secretMessage(){
      if(checkWin() && (turn >= 25)){
         System.out.println("Wow, this took a WHILE!");
      }
      if(checkWin() && (turn < 6)){
         System.out.println("You didn’t even get to the fun part :(");
      }
   }

   public static void main(String[] args) {
      System.out.println("Each player chooses where to place X or O based on numbers in a 9x9 grid formation like so:");
      System.out.println("1 2 3\n4 5 6\n7 8 9");
      System.out.println("These spots will be represented by stars like this: *");
      System.out.println("On the 6th turn, the player in control selects a previously placed \nmark and moves it to one of the three vacant spaces on the board.");
      System.out.println("3 in a row wins vertically, horizontally, or diagonally.");
      System. out.println("-------------------------------------------------------------");
      initBoard();
      printBoard();
      while (true) {
         System.out.println("Turn "+turn+":");
         choose();
         printBoard();
         if (checkWin()) {
            System.out.println(player + " wins!");
            System.out.println("It took " + turn + " turns.");
            break;
         }
         turn++;
         changePlayer();
         if (turn == 6) {
            replace();
         }
      }
   }
   private static void replace() {
      ArrayList<String> playerSpots = new ArrayList<String>();
      ArrayList<String> emptySpots = new ArrayList<String>();
      for (int i = 0; i < 9; i++) {
         if (board.get(i).equals(player)) {
            playerSpots.add(""+(i+1));
         } 
         else if (board.get(i).equals("*")) {
            emptySpots.add(""+(i+1));
         }
      }
      System.out.println("Turn "+turn+":");
      Scanner scanner = new Scanner(System.in);
      System.out.println("Player " + player + ", choose a spot to remove: "+playerSpots.get(0)+", "+playerSpots.get(1)+", or "+playerSpots.get(2));
      int removeSpot = scanner.nextInt();
       if (board.get(removeSpot-1) != player) {
         System.out.println("Spot does not have an "+player+", try again.");
         replace();
      } else {
          board.set(removeSpot-1, String.valueOf("*"));
      }

      System.out.println("Player " + player + ", choose a spot to place your piece: "+emptySpots.get(0)+", "+emptySpots.get(1)+", or "+emptySpots.get(2));
      int placeSpot = scanner.nextInt();
      if (board.get(removeSpot-1) != "*") {
         System.out.println("Spot is not empty, try again.");
         replace();
      } else {
          board.set(placeSpot-1, player);
      }
      
      printBoard();
      if (checkWin()) {
         System.out.println(player + " wins!");
         System.out.println("It took " + (turn+1) + " turns.");
         secretMessage();
         System.exit(0);
      }
      changePlayer();
      turn++;
      replace();
   }
}

